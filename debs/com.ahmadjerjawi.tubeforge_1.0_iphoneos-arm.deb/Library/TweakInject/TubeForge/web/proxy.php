<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Origin, Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With, Access-Control-Allow-Credentials');

// Function to get headers for PHP versions below 5.4
function getallheaders_compat() {
    $headers = array();
    foreach ($_SERVER as $name => $value) {
        if (substr($name, 0, 5) == 'HTTP_') {
            $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($name, 5)))));
            $headers[$header] = $value;
        }
    }
    return $headers;
}

// Retrieve request headers
$headers = array();
foreach (getallheaders_compat() as $header_name => $header_value) {
    if (strpos($header_name, 'Content-Type') === 0  || strpos($header_name, 'Authorization') === 0 || strpos($header_name, 'X-Requested-With') === 0) {
        $header_name = strtolower($header_name);
        $headers[] =  $header_name . ":" . $header_value;
    }
}

// Determine if the request is JSON or raw
$is_json_request = false;
$is_json_string_request = json_decode(file_get_contents("php://input"));

if (json_last_error() === JSON_ERROR_NONE) {
    $is_json_request = true;
    // Request validation
    if (!isset($is_json_string_request->method) || empty($is_json_string_request->method)) {
        echo json_encode(array("message" => "PROXY ACCESS DENIED!, Request method not specified"));
        exit();
    }
    if (!isset($is_json_string_request->cors) || empty($is_json_string_request->cors)) {
        echo json_encode(array("message" => "PROXY ACCESS DENIED!, CORS endpoint not specified"));
        exit();
    }

    $url = $is_json_string_request->cors;
    $method = $is_json_string_request->method;

} else {
    // Raw request handling
    if (!isset($_REQUEST['method']) || empty($_REQUEST['method'])) {
        echo json_encode(array("message" => "PROXY ACCESS DENIED!, Request method not specified"));
        exit();
    }
    if (!isset($_REQUEST['cors']) || empty($_REQUEST['cors'])) {
        echo json_encode(array("message" => "PROXY ACCESS DENIED!, CORS endpoint not specified"));
        exit();
    }

    $url = $_REQUEST['cors'];
    $method = $_REQUEST['method'];
}

// Handle the method case
switch ($method) {
    case "POST":
        $post_keys_values = $is_json_request ? (array)$is_json_string_request : $_POST;
        unset($post_keys_values['cors'], $post_keys_values['method']);

        $post_parameters = isset($is_json_request) ? json_encode($post_keys_values) : http_build_query($post_keys_values);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => "POST",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_POSTFIELDS     => $post_parameters,
            CURLOPT_HTTPHEADER     => $headers,
        ));
        break;

    case "GET":
        $get_keys_values = $is_json_request ? (array)$is_json_string_request : $_GET;
        unset($get_keys_values['cors'], $get_keys_values['method']);

        $get_params = http_build_query($get_keys_values);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL            => $url . "?" . $get_params,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER     => $headers,
        ));
        break;

    default:
        echo json_encode(array("message" => "Proxy only allows POST and GET requests"));
        exit();
}

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo json_encode(array("error" => $err));
} else {
    if (json_decode($response) !== null) {
        header('Content-Type: application/json');
    }
    echo $response;
}
?>
